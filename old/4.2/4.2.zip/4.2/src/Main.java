public class Main
{
    public static void main(String[] args)
    {
        byte byteMin = Byte.MIN_VALUE;
        byte byteMax = Byte.MAX_VALUE;
        int intMin = Integer.MIN_VALUE;
        int intMax = Integer.MAX_VALUE;
        short shortMin = Short.MIN_VALUE;
        short shortMax = Short.MAX_VALUE;
        long longMin = Long.MIN_VALUE;
        long longMax = Long.MAX_VALUE;
        float floatMin = -Float.MAX_VALUE;
        float floatMax = Float.MAX_VALUE;
        double doubleMin = - Double.MAX_VALUE;
        double doubleMax = Double.MAX_VALUE;
        System.out.println(byteMin);
        System.out.println(byteMax);
        System.out.println(intMin);
        System.out.println(intMax);
        System.out.println(shortMin);
        System.out.println(shortMax);
        System.out.println(longMin);
        System.out.println(longMax);
        System.out.println(floatMin);
        System.out.println(floatMax);
        System.out.println(doubleMin);
        System.out.println(doubleMax);
    }
}
