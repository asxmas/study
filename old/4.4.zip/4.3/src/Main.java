import com.intellij.openapi.vcs.checkin.StepIntersection;
import org.codehaus.groovy.classgen.asm.BinaryDoubleExpressionHelper;

import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        // Первое задание
//        String text = "abcdefghijklmnopqrstvwxyzабвгдеёжзийклмнопрстуфхцчшщъыьэюя";
//        String upperText = text.toUpperCase();
//        int i = 0;
//
//        for(;i < text.length(); i++)
//        {
//            int code = (int) text.charAt(i);
//            int upperCode = (int) upperText.charAt(i);
//            System.out.println(text.charAt(i) + ": " + code);
//            System.out.println(upperText.charAt(i) + ": " + upperCode);
//        }
        //  Третье задание
        System.out.println("Введите Фамилию, Имя, Отчество");
        Scanner scanner = new Scanner(System.in);
        String fullName = scanner.nextLine();
        String lastName = fullName.substring(0, fullName.indexOf(" "));
        String secondName = fullName.substring(fullName.lastIndexOf(" ") + 1);
        String name = fullName.substring(fullName.indexOf(" ") + 1, fullName.lastIndexOf(" "));
        System.out.println("Имя: " + name);
        System.out.println("Отчество: " + secondName);
        System.out.println("Фамилия: " + lastName);

        // Третье задание со звездочкой
//        System.out.println("Введите Фамилию, Имя, Отчество");
//        Scanner scanner = new Scanner(System.in);
//        String fullName = scanner.nextLine();
//        String trueFormatFullName = "";
//        while(fullName.contains("  "))
//        {
//            String trueFullName = fullName.replace("  ", " ");
//            fullName = trueFullName.trim();
//        }
//        int countWords = 0;
//        if(fullName.length() != 0)
//        {
//            countWords ++;
//            for(int i = 0; i < fullName.length(); i++)
//            {
//                if(fullName.charAt(i) == ' ')
//                    countWords ++;
//            }
//        }
//        if(countWords != 3)
//            System.out.println("Повторите ввод, не хватает/лишние слова в ФИО");
//        else {
//            fullName = fullName.toLowerCase();
//            trueFormatFullName = trueFormatFullName + fullName.substring(0, 1).toUpperCase();
//            for (int a = 1; a < fullName.length(); a++) {
//                if (" ".equals(fullName.substring(a - 1, a)))
//                    trueFormatFullName = trueFormatFullName + fullName.substring(a, a + 1).toUpperCase();
//                else
//                    trueFormatFullName = trueFormatFullName + fullName.substring(a, a + 1);
//            }
//
//            String lastName = trueFormatFullName.substring(0, trueFormatFullName.indexOf(" "));
//            String secondName = trueFormatFullName.substring(trueFormatFullName.lastIndexOf(" ") + 1);
//            String name = trueFormatFullName.substring(trueFormatFullName.indexOf(" ") + 1, trueFormatFullName.lastIndexOf(" "));
//            System.out.println("Имя: " + name);
//            System.out.println("Отчество: " + secondName);
//            System.out.println("Фамилия: " + lastName);
//        }
    }
}
