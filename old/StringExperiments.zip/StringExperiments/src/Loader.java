
public class Loader
{
    public static void main(String[] args)
    {
        String text = "Вася           заработал         5000         рублей, Петя -     7563      рубля        , а Маша - 30000 рублей";
        int rub = text.indexOf("убл");

        String text21 = text.substring(0, rub - 1);
        String text2 = text21.trim();
        String firstSum = text2.substring(text2.lastIndexOf(" ") + 1);
        String text3 = text.substring(rub + 5);
        int rub2 = text3.indexOf("убл");
        String text41 = text3.substring(0, rub2 - 1);
        String text4 = text41.trim();
        String secondSum = text4.substring(text4.lastIndexOf(" ") + 1);
        String text5 = text3.substring(rub2 + 5);
        int rub3 = text5.indexOf("убл");
        String text61 = text5.substring(0, rub3 - 1);
        String text6 = text61.trim();
        String thirdSum = text6.substring(text6.lastIndexOf(" ") + 1);
        int firstSumInt = Integer.parseInt(firstSum);
        int secondSumInt = Integer.parseInt(secondSum);
        int thirdSumInt = Integer.parseInt(thirdSum);
        int sum = firstSumInt + secondSumInt + thirdSumInt;
        System.out.println(sum);
    }
}