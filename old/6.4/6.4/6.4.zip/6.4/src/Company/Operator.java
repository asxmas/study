package Company;

public class Operator implements Employee{

    private int salary;
    public Operator(Company company) {
        this.salary = ((int)(300 + Math.random()*100)*100);
    }

    @Override
    public double getMonthSalary() {
        return this.salary;
    }
}
