package Company;

public class Manager implements Employee{

    private int salary;
    private int sales;

    public Manager(Company company) {
        this.sales = ((int)(3000 + Math.random()*1000)*100);
        this.salary = ((int)(((800 + Math.random()*100)*100) + Math.round(getSales()*0.05)));
    }
    public int getSales() {
        return sales;
    }

    @Override
    public double getMonthSalary() {
        return this.salary;
    }
}
