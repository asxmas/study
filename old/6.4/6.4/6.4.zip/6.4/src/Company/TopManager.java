package Company;

public class TopManager implements Employee{

    private int salary;
    private double bonusKoefficient = 2.5;
    private Company company;

    public TopManager(Company company) {
        this.company = company;
        this.salary = ((int)((1700 + Math.random() * 300) * 100));
    }

    @Override
    public double getMonthSalary() {
        if(company.getIncome() > 10000000){
            return salary * bonusKoefficient;
        }
        return this.salary;
    }
}
