package Company;

public interface Employee extends Comparable<Employee> {

    double getMonthSalary();

    default int compareTo(Employee employee){
        if (getMonthSalary() > employee.getMonthSalary()) {
            return -1;
        }
        if (getMonthSalary() < employee.getMonthSalary()) {
            return 1;
        }
        return 0;
    }
}
