package Company;

import java.util.ArrayList;
import java.util.Collections;

public class Company {
    private ArrayList<Employee> staff;
    private static int income;

    public Company (){
        staff = new ArrayList<>();
        this.income = 0;
        }

    public void hire(Employee employee){
        staff.add(employee);
        if(employee instanceof Manager) {
            income = income + ((Manager)employee).getSales();
        }
    }

    public void hireAll(ArrayList<Employee> list){
        for (int i = 0;i < list.size(); i++){
            hire(list.get(i));
        }
    }

    public void fire(int indexOfEmployee){
        staff.remove(staff.get(indexOfEmployee));
        if(staff.get(indexOfEmployee) instanceof Manager){
            income = income - ((Manager)staff.get(indexOfEmployee)).getSales();
        }
    }

    public int getIncome(){
        return income;
    }

    public void printIncome(){
        System.out.println("Прибыль компании составляет: "  + income + " руб.");
    }

    public ArrayList<Employee> sortSalaryStaff(int count)
    {
        if(count > staff.size()){
            count = staff.size();
            System.out.println("Так как кол-во сотрудников в компании меньше запрашиваемых - мы предоставим отсортированный список всех зарплат");
        }
        ArrayList<Employee> sortSalaryStaff = new ArrayList<>();
        for(int i = 0;i < staff.size();i++){
            sortSalaryStaff.add(staff.get(i));
        }
        Collections.sort(sortSalaryStaff);

        return sortSalaryStaff;
    }

    public ArrayList<Employee> getTopSalaryStaff(int count) {
        ArrayList<Employee> topSalaryStaff = new ArrayList<>(count);
        sortSalaryStaff(count);

        for (int i = 0; i < count; i++) {
            topSalaryStaff.add(sortSalaryStaff(count).get(i));
        }
            return topSalaryStaff;
    }

    public ArrayList<Employee> getLowSalaryStaff(int count){
        ArrayList<Employee> lowSalaryStaff = new ArrayList<>(count);
        sortSalaryStaff(count);
        for(int i = sortSalaryStaff(count).size() - 1; i >= (sortSalaryStaff(count).size() - count); i--) {
            lowSalaryStaff.add(sortSalaryStaff(count).get(i));
        }
            return lowSalaryStaff;
    }

    public void printStaff(ArrayList<Employee> arrayList){
        for(Employee a : arrayList){
            System.out.println(a + " - " + a.getMonthSalary());
        }
    }
}
