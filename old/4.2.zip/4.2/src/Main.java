public class Main
{
    public static void main(String[] args)
    {
//        грузовики, контейнеры, ящики;
//        Грузовик = 12 контейнеров;
//        контейнер = 27 ящиков;

    Shipment firstTry = new Shipment();
        {
            firstTry.boxesQuantity();
            firstTry.needResources();
            firstTry.loadTrucks();
        }

        }

}
