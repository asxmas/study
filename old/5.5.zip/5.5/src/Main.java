import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main
{
    public static void main(String[] args) {
        ArrayList<String> numbersList = new ArrayList<>();

        // А111АА197
        // СМТВАРОНЕУ
        for (int num = 1; num < 10; num++) {
            for (int region = 1; region < 198; region++) {
                for (char character1 = 'А'; character1 < 'Я'; character1++) {
                    for (char character2 = 'А'; character2 < 'Я'; character2++) {
                        for (char character3 = 'А'; character3 < 'Я'; character3++) {
                            String characterString = "" + character1 + character2 + character3;
                            if (checkCharacter(characterString)) {
                                numbersList.add("" + character1 + num + num + num + character2 + character3 + region);
                            }
                        }
                    }
                }
            }
        }
        System.out.println(numbersList.size());
        Collections.sort(numbersList);



        HashSet<String> numberListHash = new HashSet<>();
        numberListHash.addAll(numbersList);
        TreeSet<String> numberListTree = new TreeSet<>();
        numberListTree.addAll(numbersList);

        for(;;){
        System.out.println("Введите государственный номер");
        Scanner scanner = new Scanner(System.in);
        String number = scanner.nextLine();
            if(checkNumber(number)) {
                long containsStart = System.nanoTime();
                int containsIndex = numbersList.indexOf(number);
                long containsDuration = System.nanoTime() - containsStart;
                System.out.println("Время поиска методом перебора: " + containsDuration);

                long binaryStart = System.nanoTime();
                int binaryIndex = Collections.binarySearch(numbersList, number);
                long binaryDuration = System.nanoTime() - binaryStart;
                System.out.println("Время поиска бинарным методом: " + binaryDuration);

                long treeSetStart = System.nanoTime();
                numberListTree.contains(number);
                long treeSetDuration = System.nanoTime() - treeSetStart;
                System.out.println("Время поиска из списка Tree: " + treeSetDuration);

                long hashSetStart = System.nanoTime();
                numberListHash.contains(number);
                long hashSetDuration = System.nanoTime() - hashSetStart;
                System.out.println("Время поиска из списка Hash: " + hashSetDuration);
            }
            else {
                System.out.println("Пожалуйста, постарайтесь ввести номер правильно");
                return;
            }

//            ArrayList<String> items = new ArrayList<>();
//            Collections.sort(items);
//            int index = Collections.binarySearch(items, "asdf");
//            System.out.println(index);
        }

    }

    private static boolean checkCharacter(String s)
    {
        Pattern pattern = Pattern.compile("[АВЕКМНОРСТУХ]{3,3}");
        Matcher matcher = pattern.matcher(s);
        return matcher.matches();
    }
    private static boolean checkNumber(String s)
    {
        Pattern pattern = Pattern.compile("[АВЕКМНОРСТУХ][0-9]{3,3}[АВЕКМНОРСТУХ]{2,2}[0-9]{1,3}");
        Matcher matcher = pattern.matcher(s);
        return matcher.matches();
    }
}
