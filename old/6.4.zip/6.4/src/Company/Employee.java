package Company;

public interface Employee extends Comparable<Employee> {

    double getMonthSalary();
}
